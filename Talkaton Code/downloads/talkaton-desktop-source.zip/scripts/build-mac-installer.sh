#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/talkaton-macos.XXXXXX")"
APP_DIR="$WORK_DIR/Talkaton.app"
STAGE_DIR="$WORK_DIR/stage"
OUTPUT_DIR="$PROJECT_DIR/downloads/installers"
OUTPUT_FILE="$OUTPUT_DIR/Talkaton-1.0.0-mac-universal.dmg"
SOURCE_FILE="$PROJECT_DIR/desktop/macos/TalkatonApp.m"

cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT

mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources" "$STAGE_DIR" "$OUTPUT_DIR"
clang "$SOURCE_FILE" -target arm64-apple-macos13.0 -fobjc-arc -fmodules-cache-path="$WORK_DIR/module-cache-arm64" -framework Cocoa -framework WebKit -o "$WORK_DIR/Talkaton-arm64"
clang "$SOURCE_FILE" -target x86_64-apple-macos13.0 -fobjc-arc -fmodules-cache-path="$WORK_DIR/module-cache-x64" -framework Cocoa -framework WebKit -o "$WORK_DIR/Talkaton-x64"
lipo -create "$WORK_DIR/Talkaton-arm64" "$WORK_DIR/Talkaton-x64" -output "$APP_DIR/Contents/MacOS/Talkaton"
cp "$PROJECT_DIR/desktop/macos/Info.plist" "$APP_DIR/Contents/Info.plist"
cp "$PROJECT_DIR/desktop/assets/Talkaton.icns" "$APP_DIR/Contents/Resources/Talkaton.icns"
chmod +x "$APP_DIR/Contents/MacOS/Talkaton"
codesign --force --deep --sign - "$APP_DIR"
cp -R "$APP_DIR" "$STAGE_DIR/Talkaton.app"
ln -s /Applications "$STAGE_DIR/Applications"
rm -f "$OUTPUT_FILE"
hdiutil create -volname "Talkaton" -srcfolder "$STAGE_DIR" -ov -format UDZO "$OUTPUT_FILE"
codesign --verify --deep --strict "$APP_DIR"
file "$APP_DIR/Contents/MacOS/Talkaton"
hdiutil verify "$OUTPUT_FILE"
