import { enforceGuestUsage, GuestUsageError } from "./_guest-guard.js";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", ["POST"]);
    return res.status(405).json({
      error: "Method not allowed"
    });
  }

  const controller = new AbortController();
  let timedOut = false;
  let clientDisconnected = false;

  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 60000);

  const handleClientDisconnect = () => {
    if (res.writableEnded) return;
    clientDisconnected = true;
    controller.abort();
  };
  res.once("close", handleClientDisconnect);

  try {
    const prompt = String(req.body?.prompt || "").trim();

    if (!prompt) {
      clearTimeout(timeout);
      return res.status(400).json({
        error: "Image prompt is required."
      });
    }

    await enforceGuestUsage(req, "images");

    const outputFormat = "webp";
    const response = await fetch(
      "https://api.openai.com/v1/images/generations",
      {
        method: "POST",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${getOpenAIApiKey()}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: "gpt-image-1-mini",
          prompt,
          size: "1024x1024",
          quality: "low",
          output_format: outputFormat,
          output_compression: 65
        })
      }
    );

    const responseText = await response.text();
    let data;
    try {
      data = JSON.parse(responseText);
    } catch {
      return res.status(500).json({
        error: "OpenAI returned invalid JSON.",
        response: responseText
      });
    }

    if (!response.ok) {
      return res.status(response.status).json({
        error:
          data?.error?.message ||
          `OpenAI request failed (${response.status})`,
        details: data
      });
    }

    if (!Array.isArray(data.data) || data.data.length === 0) {
      return res.status(500).json({
        error: "No image was returned.",
        details: data
      });
    }

    const image = data.data[0];

    return res.status(200).json({
      success: true,
      image: {
        ...image,
        output_format: outputFormat,
        mime_type: `image/${outputFormat}`
      },
      provider: "openai",
      model: "gpt-image-1-mini"
    });
  } catch (err) {
    if (err instanceof GuestUsageError) {
      return res.status(err.status).json({
        error: err.message,
        code: err.code
      });
    }

    if (err.name === "AbortError") {
      if (clientDisconnected) return;
      return res.status(504).json({
        error: timedOut ? "Image generation timed out." : "Image generation was canceled."
      });
    }

    console.error(err);

    return res.status(500).json({
      error: err.message || "Unknown server error."
    });
  } finally {
    clearTimeout(timeout);
    res.off("close", handleClientDisconnect);
  }
}

function getOpenAIApiKey() {
  const key = process.env.OPENAI_API_KEY?.trim();

  if (!key) {
    throw new Error("OPENAI_API_KEY is missing.");
  }

  return key.startsWith("Bearer ")
    ? key.slice(7)
    : key;
}
