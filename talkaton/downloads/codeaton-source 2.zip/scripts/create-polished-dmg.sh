#!/bin/bash
set -euo pipefail

if [[ $# -ne 4 ]]; then
  echo "Usage: create-polished-dmg.sh <app-path> <product> <accent> <output.dmg>" >&2
  exit 2
fi

APP_PATH="$1"
PRODUCT="$2"
ACCENT="$3"
OUTPUT_FILE="$4"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORK_DIR="$(mktemp -d "${TMPDIR:-/tmp}/installer-dmg.XXXXXX")"
STAGE_DIR="$WORK_DIR/stage"
RW_DMG="$WORK_DIR/${PRODUCT}-rw.dmg"
BACKGROUND_FILE="$WORK_DIR/background.png"
VOLUME_NAME="$PRODUCT Installer"

cleanup() {
  if mount | grep -q "/Volumes/$VOLUME_NAME"; then hdiutil detach "/Volumes/$VOLUME_NAME" -quiet || true; fi
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

mkdir -p "$STAGE_DIR/.background" "$(dirname "$OUTPUT_FILE")"
clang "$SCRIPT_DIR/make-dmg-background.m" -fobjc-arc -fmodules-cache-path="$WORK_DIR/module-cache" -framework Cocoa -o "$WORK_DIR/make-dmg-background"
"$WORK_DIR/make-dmg-background" "$BACKGROUND_FILE" "$PRODUCT" "$ACCENT"
cp -R "$APP_PATH" "$STAGE_DIR/$PRODUCT.app"
cp "$BACKGROUND_FILE" "$STAGE_DIR/.background/background.png"
ln -s /Applications "$STAGE_DIR/Applications"
touch "$STAGE_DIR/.metadata_never_index"

hdiutil create -srcfolder "$STAGE_DIR" -volname "$VOLUME_NAME" -fs HFS+ -format UDRW -ov "$RW_DMG" >/dev/null
hdiutil attach "$RW_DMG" -readwrite -noverify -noautoopen >/dev/null

osascript <<APPLESCRIPT
tell application "Finder"
  tell disk "$VOLUME_NAME"
    open
    set current view of container window to icon view
    set toolbar visible of container window to false
    set statusbar visible of container window to false
    set pathbar visible of container window to false
    set bounds of container window to {160, 120, 800, 540}
    set arrangement of icon view options of container window to not arranged
    set icon size of icon view options of container window to 96
    set text size of icon view options of container window to 13
    set background picture of icon view options of container window to file ".background:background.png"
    set position of item "$PRODUCT.app" of container window to {160, 220}
    set position of item "Applications" of container window to {480, 220}
    set extension hidden of item "$PRODUCT.app" of container window to true
    update without registering applications
    delay 2
    close
  end tell
end tell
APPLESCRIPT

sync
hdiutil detach "/Volumes/$VOLUME_NAME" -quiet
rm -f "$OUTPUT_FILE"
hdiutil convert "$RW_DMG" -format UDZO -imagekey zlib-level=9 -o "$OUTPUT_FILE" >/dev/null
hdiutil verify "$OUTPUT_FILE" >/dev/null
